<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dressingnity Home page</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <!-- RemixIcon CDN -->
    <link href="https://cdn.jsdelivr.net/npm/remixicon@2.5.0/fonts/remixicon.css" rel="stylesheet">
    <!-- Font Awesome CDN -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css"
        integrity="sha384-B4dIYHKNBt8Bc12p+WXckhzcICo0wtJAoU8YZTY5qE0Id1GSseTk6S+L3BlXeVIU" crossorigin="anonymous">
    <!-- Styles.css -->
    <link rel="stylesheet" href="CSS/Styles.css">
</head>

<body>
    <!-- Navbar Starts -->
    <nav class="shadow sticky-top ms-1 me-1 rounded-bottom navbar navbar-expand-lg navbar-light bg-light">
        <!-- Container wrapper -->
        <div class="container-fluid">

            <!-- Navbar brand -->
            <a class="navbar-brand" href="https://prakash4844.github.io/Dressingnity-Ecommerce-Website/"><img
                    style="height:60px;" src="Images/SVG Samples/Dressingnity (LOGO-final).svg" alt="BrandLogo"></a>

            <!-- Toggle button -->
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                aria-label="Toggle navigation">
                <i class="fas fa-bars"></i>
            </button>

            <!-- Collapsible wrapper -->
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <!-- Left links -->
                <ul class="navbar-nav me-3">
                    <li class="nav-item">
                        <div class="dropdown">
                            <a class="btn btn-light dropdown-toggle vio-outline" href="#" role="button"
                                data-bs-toggle="dropdown" aria-expanded="false">
                                <i class="fas fa-bars pe-2"></i> Menu
                            </a>

                            <ul class="dropdown-menu dropdown-menu-light" style="margin-top: 17px;">
                                <!-- Try to Fix Dropdown position by removing inline CSS -->
                                <li>
                                    <a class="dropdown-item" href="#collection">
                                        <i class="ri-genderless-line"></i> All</a>
                                </li>
                                <li>
                                    <hr class="dropdown-divider">
                                </li>

                                <li>
                                    <a class="dropdown-item" href="special-m">
                                        <i class="ri-t-shirt-2-line"></i> Men</a>
                                </li>
                                <li>
                                    <a class="dropdown-item" href="special">
                                        <i class="ri-t-shirt-line"></i> Women</a>
                                </li>
                            </ul>
                        </div>
                    </li>
                </ul>
                <!-- Left links -->

                <form class="d-flex align-items-center w-100 form-search">
                    <div class="input-group">
                        <button class="rounded btn btn-light dropdown-toggle shadow-0 vio-outline" type="button"
                            data-bs-toggle="dropdown" aria-expanded="false" style="padding-bottom: 0.4rem;">
                            All
                        </button>
                        <ul class="dropdown-menu dropdown-menu-light" style="margin-top: 15px;">
                            <!-- Try to Fix Dropdown position by removing inline CSS -->
                            <li>
                                <a class="dropdown-item" href="#collection"><span class="fa-li pe-2"><i
                                            class="ri-genderless-line"></i></span>All</a>
                            </li>
                            <li>
                                <hr class="dropdown-divider">
                            </li>
                            <li>
                                <a class="dropdown-item" href="#special-m"><span class="fa-li pe-2"><i
                                            class="ri-t-shirt-2-line"></i></span>Men</a>
                            </li>
                            <li>
                                <a class="dropdown-item" href="#special"><span class="fa-li pe-2"><i
                                            class="ri-t-shirt-line"></i></span>Women</a>
                            </li>
                            <li>
                        </ul>
                        <input class="form-control rounded" type="search" placeholder="Search anything"
                            aria-label="Search">
                        <button class="btn btn-light vio-outline" type="submit"><i class="ri-search-line"></i></button>
                    </div>
                </form>

                <ul class="navbar-nav ms-3">
                    <li class="nav-item me-3">
                        <a class="nav-link d-flex align-items-center vio-outline" href="#!"><i
                                class="ri-notification-line"></i></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link d-flex align-items-center me-3" href="cart.php">
                            <i class="ri-shopping-cart-line"></i>
                        </a>
                    </li>
                    <li class="nav-item" style="width: 65px;">
                        <a class="btn btn-light vio-outline rounded nav-link d-flex align-items-center sign-in"
                            href="Login.php">Sign In</a>
                    </li>
                </ul>
            </div>

            <!-- Collapsible wrapper -->
        </div>
        <!-- Container wrapper -->
    </nav>
    <!-- Navbar Ends -->


       <!-- ******************************************************************************************************************************* -->

    <!-- header -->
    <div id="carouselExampleDark" class="carousel carousel-dark slide" data-bs-ride="carousel">
        <div class="carousel-indicators">
          <button type="button" data-bs-target="#carouselExampleDark" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
          <button type="button" data-bs-target="#carouselExampleDark" data-bs-slide-to="1" aria-label="Slide 2"></button>
          <button type="button" data-bs-target="#carouselExampleDark" data-bs-slide-to="2" aria-label="Slide 3"></button>
        </div>
        <div class="carousel-inner">
          <div class="carousel-item active" data-bs-interval="10000">
            <img src="Images/HomePage/sliderimg1.jpg" class="d-block w-100" alt="...">
            <div class="carousel-caption d-none d-md-block">
              <h1>First slide label</h1>
              <p class="fs-5">Some representative placeholder content for the first slide. Lorem, ipsum dolor sit amet consectetur adipisicing elit. Odit distinctio perferendis magni aut, tempora temporibus.</p>
            </div>
          </div>
          <div class="carousel-item" data-bs-interval="2000">
            <img src="Images/HomePage/wallpepergirls.jpg" class="d-block w-100" alt="...">
            <div class="carousel-caption d-none d-md-block">
              <h1>Second slide label</h1>
              <p class="fs-5">Some representative placeholder content for the second slide. Lorem, ipsum dolor sit amet consectetur adipisicing elit. Odit distinctio perferendis magni aut, tempora temporibus.</p>
            </div>
          </div>
          <div class="carousel-item">
            <img src="Images/HomePage/sliderimg3.jpg" class="d-block w-100" alt="...">
            <div class="carousel-caption d-none d-md-block">
              <h1>Third slide label</h1>
              <p class="fs-5">Some representative placeholder content for the third slide. Lorem, ipsum dolor sit amet consectetur adipisicing elit. Odit distinctio perferendis magni aut, tempora temporibus.</p>
            </div>
          </div>
        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleDark" data-bs-slide="prev">
          <span class="carousel-control-prev-icon" aria-hidden="true"></span>
          <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleDark" data-bs-slide="next">
          <span class="carousel-control-next-icon" aria-hidden="true"></span>
          <span class="visually-hidden">Next</span>
        </button>
      </div>

    <!-- end of header -->


    <!-- collection -->
    <section id="collection" class="py-5">
        <div class="container">
            <div class="title text-center">
                <h2 class="position-relative d-inline-block">New Collection</h2>
            </div>

            <div class="row g-0">
                <div class="d-flex flex-wrap justify-content-center mt-5 filter-button-group collection-btn">
                    <button type="button" class="btn m-2 text-dark  active-filter-btn" data-filter="*"><a class="fs-4 " href = "#collection" class = "btn   mt-3">All</a></button>
                    <button type="button" class="btn m-2 text-dark " data-filter=".best"><a class="fs-4 " href = "#special" class = "btn   mt-3">Female Section</a></button>
                    <button type="button" class="btn m-2 text-dark " data-filter=".feat"><a class="fs-4 " href = "#special-m" class = "btn   mt-3">Male Section</a></button>
                    <button type="button" class="btn m-2 text-dark " data-filter=".new"><a class="fs-4 " href = "#popular" class = "btn   mt-3">Products</a></button>
                </div>

                <div class="collection-list mt-4 row gx-0 gy-3">
                    <div class="col-sm-12 col-md-6 col-lg-4 col-xl-3 p-2 best">
                        <div class="collection-img position-relative">
                            <p><a href="Products.php"><img
                                        src="https://rukminim1.flixcart.com/image/832/832/shirt/k/h/n/bfgreysht02-being-fab-40-original-imaecvnxyxg44vre.jpeg?q=70"
                                        class="w-100 alt=""></a></p>
                            </div>
                            <div class = " text-center">
                                    
                                    <p class="text-capitalize my-1">gray shirt</p>
                                    <span class="fw-bold">$ 45.50</span>
                        </div>
                    </div>

                    <div class="col-sm-12 col-md-6 col-lg-4 col-xl-3 p-2 feat">
                        <div class="collection-img position-relative">
                            <p><a href="Products.php"><img
                                        src="https://rukminim1.flixcart.com/image/832/832/shirt/k/h/n/bfgreysht02-being-fab-40-original-imaecvnxyxg44vre.jpeg?q=70"
                                        class="w-100 alt=""></a></p>
                               
                        </div>
                        <div class="text-center">
                            
                            <p class="text-capitalize my-1">gray shirt</p>
                            <span class="fw-bold">$ 45.50</span>
                        </div>
                    </div>

                    <div class="col-sm-12 col-md-6 col-lg-4 col-xl-3 p-2 new">
                        <div class="collection-img position-relative">
                            <p><a href="Products.php"><img
                                        src="https://rukminim1.flixcart.com/image/832/832/shirt/k/h/n/bfgreysht02-being-fab-40-original-imaecvnxyxg44vre.jpeg?q=70"
                                        class="w-100 alt=""></a></p>
                              
                        </div>
                        <div class="text-center">
                        
                            <p class="text-capitalize my-1">gray shirt</p>
                            <span class="fw-bold">$ 45.50</span>
                        </div>
                    </div>

                    <div class="col-sm-12 col-md-6 col-lg-4 col-xl-3  p-2 best">
                        <div class="collection-img position-relative">
                            <p><a href="Products.php"><img
                                        src="https://rukminim1.flixcart.com/image/832/832/shirt/k/h/n/bfgreysht02-being-fab-40-original-imaecvnxyxg44vre.jpeg?q=70"
                                        class="w-100 alt=""></a></p>
                               
                        </div>
                        <div class="text-center">
                           
                            <p class="text-capitalize my-1">gray shirt</p>
                            <span class="fw-bold">$ 45.50</span>
                        </div>
                    </div>

                    <div class="col-sm-12 col-md-6 col-lg-4 col-xl-3 p-2 feat">
                        <div class="collection-img position-relative">
                            <p><a href="Products.php"><img
                                        src="https://rukminim1.flixcart.com/image/832/832/shirt/k/h/n/bfgreysht02-being-fab-40-original-imaecvnxyxg44vre.jpeg?q=70"
                                        class="w-100 alt=""></a></p>
                               
                        </div>
                        <div class="text-center">
                            
                            <p class="text-capitalize my-1">gray shirt</p>
                            <span class="fw-bold">$ 45.50</span>
                        </div>
                    </div>

                    <div class="col-sm-12 col-md-6 col-lg-4 col-xl-3 p-2 new">
                        <div class="collection-img position-relative">
                            <p><a href="Products.php"><img
                                        src="https://rukminim1.flixcart.com/image/832/832/shirt/k/h/n/bfgreysht02-being-fab-40-original-imaecvnxyxg44vre.jpeg?q=70"
                                        class="w-100 alt=""></a></p>
                                
                        </div>
                        <div class="text-center">
                           
                            <p class="text-capitalize my-1">gray shirt</p>
                            <span class="fw-bold">$ 45.50</span>
                        </div>
                    </div>

                    <div class="col-sm-12 col-md-6 col-lg-4 col-xl-3  p-2 best">
                        <div class="collection-img position-relative">
                            <p><a href="Products.php"><img
                                        src="https://rukminim1.flixcart.com/image/832/832/shirt/k/h/n/bfgreysht02-being-fab-40-original-imaecvnxyxg44vre.jpeg?q=70"
                                        class="w-100 alt=""  ></a></p>
                               
                        </div>
                        <div class="text-center">
                        
                            <p class="text-capitalize my-1">gray shirt</p>
                            <span class="fw-bold">$ 45.50</span>
                        </div>
                    </div>

                    <div class="col-sm-12 col-md-6 col-lg-4 col-xl-3  p-2 feat">
                        <div class="collection-img position-relative">
                            <p><a href="Products.php">
                                <img src="https://rukminim1.flixcart.com/image/832/832/shirt/k/h/n/bfgreysht02-being-fab-40-original-imaecvnxyxg44vre.jpeg?q=70"
                                        class="w-100 alt=""></a></p>
                             
                        </div>
                        <div class="text-center">
                            <p class="text-capitalize my-1">gray shirt</p>
                            <span class="fw-bold">$ 45.50</span>
                        </div>
                    </div>
                    <!-- <a href="Products.html"><button type="button"  class="btn  ">Products</button></a>  -->
                </div>
            </div>
        </div>
    </section>
    <!-- end of collection -->


     <!-- special products Female-->
     <section id = "special" class = "py-5">
        <div class = "container">
            <div class = "title text-center py-5">
                <h2 class = "position-relative d-inline-block">Female Collection</h2>
            </div>

            <div class = "special-list row g-0">
                <div class = "col-md-6 col-lg-4 col-xl-3 p-2">
                    <div class = "special-img position-relative overflow-hidden">
                        <img src="https://rukminim1.flixcart.com/image/832/832/shirt/k/h/n/bfgreysht02-being-fab-40-original-imaecvnxyxg44vre.jpeg?q=70" class = "w-100">
                          
                    </div>
                    <div class = "text-center">
                        <p class = "text-capitalize mt-3 mb-1">gray shirt</p>
                        <span class = "fw-bold d-block">$ 45.50</span>
                        <a href = "#" class = "btn btn-add rounded-3 text-white mt-3"> Cart </a>
                    </div>
                </div>

                <div class = "col-md-6 col-lg-4 col-xl-3 p-2">
                    <div class = "special-img position-relative overflow-hidden">
                        <img src="https://rukminim1.flixcart.com/image/832/832/shirt/k/h/n/bfgreysht02-being-fab-40-original-imaecvnxyxg44vre.jpeg?q=70" class = "w-100">
                          
                    </div>
                    <div class = "text-center">
                        <p class = "text-capitalize mt-3 mb-1">gray shirt</p>
                        <span class = "fw-bold d-block">$ 45.50</span>
                        <a href = "#" class = "btn btn-add rounded-3 text-white  mt-3"> Cart </a>
                    </div>
                </div>

                <div class = "col-md-6 col-lg-4 col-xl-3 p-2">
                    <div class = "special-img position-relative overflow-hidden">
                        <img src="https://rukminim1.flixcart.com/image/832/832/shirt/k/h/n/bfgreysht02-being-fab-40-original-imaecvnxyxg44vre.jpeg?q=70" class = "w-100">
                          
                    </div>
                    <div class = "text-center">
                        <p class = "text-capitalize mt-3 mb-1">gray shirt</p>
                        <span class = "fw-bold d-block">$ 45.50</span>
                        <a href = "#" class = "btn btn-add rounded-3 text-white  mt-3"> Cart </a>
                    </div>
                </div>

                <div class = "col-md-6 col-lg-4 col-xl-3 p-2">
                    <div class = "special-img position-relative overflow-hidden">
                        <img src="https://rukminim1.flixcart.com/image/832/832/shirt/k/h/n/bfgreysht02-being-fab-40-original-imaecvnxyxg44vre.jpeg?q=70" class = "w-100">
                          
                    </div>
                    <div class = "text-center">
                        <p class = "text-capitalize mt-3 mb-1">gray shirt</p>
                        <span class = "fw-bold d-block">$ 45.50</span>
                        <a href = "#" class = "btn btn-add rounded-3 text-white  mt-3"> Cart </a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- end of special products -->


     
 <!-- special products  Male-->
 <section id = "special-m" class = "py-5">
    <div class = "container">
        <div class = "title text-center py-5">
            <h2 class = "position-relative d-inline-block">Male Collection</h2>
        </div>

        <div class = "special-list row g-0">
            <div class = "col-md-6 col-lg-4 col-xl-3 p-2">
                <div class = "special-img position-relative overflow-hidden">
                    <img src="https://rukminim1.flixcart.com/image/832/832/shirt/k/h/n/bfgreysht02-being-fab-40-original-imaecvnxyxg44vre.jpeg?q=70" class = "w-100">
                       
                </div>
                <div class = "text-center">
                    <p class = "text-capitalize mt-3 mb-1">gray shirt</p>
                    <span class = "fw-bold d-block">$ 45.50</span>
                    <a href = "#" class = "btn btn-add rounded-3 text-white  mt-3"> Cart </a>
                </div>
            </div>

            <div class = "col-md-6 col-lg-4 col-xl-3 p-2">
                <div class = "special-img position-relative overflow-hidden">
                    <img src="https://rukminim1.flixcart.com/image/832/832/shirt/k/h/n/bfgreysht02-being-fab-40-original-imaecvnxyxg44vre.jpeg?q=70" class = "w-100">
                       
                </div>
                <div class = "text-center">
                    <p class = "text-capitalize mt-3 mb-1">gray shirt</p>
                    <span class = "fw-bold d-block">$ 45.50</span>
                    <a href = "#" class = "btn btn-add rounded-3 text-white  mt-3"> Cart </a>
                </div>
            </div>

            <div class = "col-md-6 col-lg-4 col-xl-3 p-2">
                <div class = "special-img position-relative overflow-hidden">
                    <img src="https://rukminim1.flixcart.com/image/832/832/shirt/k/h/n/bfgreysht02-being-fab-40-original-imaecvnxyxg44vre.jpeg?q=70" class = "w-100">
                       
                </div>
                <div class = "text-center">
                    <p class = "text-capitalize mt-3 mb-1">gray shirt</p>
                    <span class = "fw-bold d-block">$ 45.50</span>
                    <a href = "#" class = "btn btn-add rounded-3 text-white  mt-3"> Cart </a>
                </div>
            </div>

            <div class = "col-md-6 col-lg-4 col-xl-3 p-2">
                <div class = "special-img position-relative overflow-hidden">
                    <img src="https://rukminim1.flixcart.com/image/832/832/shirt/k/h/n/bfgreysht02-being-fab-40-original-imaecvnxyxg44vre.jpeg?q=70" class = "w-100">
                       
                </div>
                <div class = "text-center">
                    <p class = "text-capitalize mt-3 mb-1">gray shirt</p>
                    <span class = "fw-bold d-block">$ 45.50</span>
                    <a href = "#" class = "btn btn-add rounded-3 text-white  mt-3"> Cart </a>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- end of special products -->


 <!-- Testimonials start-->

 <section id="testimonials">
    <div id="testimonial-carousel" class="carousel slide" data-ride="false" >
      <div class="carousel-inner">
        
        
            <div class="carousel-item active" >
              <h2>I no longer have to sniff other cats for love. I've found the hottest Corgi on TinCat. Woof.</h2>
              <img class="testimonial-image" src="Images/HomePage/testimon1.jpeg" alt="dog-profile">
              <em>Pebbles, New York</em>
            </div>

            <div class="carousel-item ">
              <h2 class="testimonial-text">My cat used to be so lonely , but with TinCat's help, they've found the rhfy grbgry rtrgtg</h2>
              <img class="testimonial-image" src="Images/HomePage/testimon2.jpg" alt="lady">
              <em>Beverly, Illinois</em>
            </div>
       
      </div>
         <button class="carousel-control-prev" type="button"  data-bs-target="#testimonial-carousel" data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
           <span class="visually-hidden">Previous</span>
         </button>
      <button class="carousel-control-next" type="button" data-bs-target="#testimonial-carousel" data-bs-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Next</span>
     </button>

    </div>


  </section>


  <!-- Press -->

  <section id="press">
    <img class="press-logo" src="Images/HomePage/test6.png" alt="tc-logo">
    <img class="press-logo" src="Images/HomePage/test2.png" alt="tnw-logo">
    <img class="press-logo" src="Images/HomePage/test3.png" alt="biz-insider-logo">
    <img class="press-logo" src="Images/HomePage/test4 (2).png" alt="mashable-logo">

  </section> 
  <!-- press end -->

<!-- Testimonials End -->


    <!-- blogs -->
    <section id = "offers" class = "py-5">
        <div class = "container">
            <div class = "row d-flex align-items-center justify-content-center text-center justify-content-lg-start text-lg-start">
                <div class = "offers-content">
                    <span class = "text-black">Discount Up To 15%</span>
                    <h2 class = "mt-2 mb-4 text-black">Grand Sale Offer!</h2>
                    <a href = "#" class = "btn btn-warning">Buy Now</a>
                </div>
            </div>
        </div>
    </section>
    <!-- end of blogs -->

    <!-- popular  products -->
    <section id="popular" class="py-5">
        <div class="container">
            <div class="title text-center pt-3 pb-5">
                <h2 class="position-relative d-inline-block ms-4">Products</h2>
            </div>

            <div class="row">
                <div class="col-md-6 col-lg-4 col-md-12 row g-3 ">
                    <h3 class="fs-5 popular-type">Top Rated</h3>
                    <div class="d-flex align-items-start justify-content-start popular-product">
                        <img src="https://rukminim1.flixcart.com/image/832/832/shirt/k/h/n/bfgreysht02-being-fab-40-original-imaecvnxyxg44vre.jpeg?q=70"
                            alt="" class="img-fluid pe-3 w-25">
                        <div>
                            <p class="mb-0">Sundress</p>
                            <span>$ 20.00</span>
                        </div>
                    </div>
                    <div class="d-flex align-items-start justify-content-start popular-product">
                        <img src="https://rukminim1.flixcart.com/image/832/832/shirt/k/h/n/bfgreysht02-being-fab-40-original-imaecvnxyxg44vre.jpeg?q=70"
                            alt="" class="img-fluid pe-3 w-25">
                        <div>
                            <p class="mb-0">Shirtdress</p>
                            <span>$ 20.00</span>
                        </div>
                    </div>
                    <div class="d-flex align-items-start justify-content-start popular-product">
                        <img src="https://rukminim1.flixcart.com/image/832/832/shirt/k/h/n/bfgreysht02-being-fab-40-original-imaecvnxyxg44vre.jpeg?q=70"
                            alt="" class="img-fluid pe-3 w-25">
                        <div>
                            <p class="mb-0">Cardign</p>
                            <span>$ 20.00</span>
                        </div>
                    </div>
                </div>

                <div class="col-md-6 col-lg-4 col-md-12 row g-3">
                    <h3 class="fs-5 popular-type">Best Selling</h3>
                    <div class="d-flex align-items-start justify-content-start popular-product">
                        <img src="https://rukminim1.flixcart.com/image/832/832/shirt/k/h/n/bfgreysht02-being-fab-40-original-imaecvnxyxg44vre.jpeg?q=70"
                            alt="" class="img-fluid pe-3 w-25">
                        <div>
                            <p class="mb-0">Trousers</p>
                            <span>$ 20.00</span>
                        </div>
                    </div>
                    <div class="d-flex align-items-start justify-content-start popular-product">
                        <img src="https://rukminim1.flixcart.com/image/832/832/shirt/k/h/n/bfgreysht02-being-fab-40-original-imaecvnxyxg44vre.jpeg?q=70"
                            alt="" class="img-fluid pe-3 w-25">
                        <div>
                            <p class="mb-0">Coat</p>
                            <span>$ 20.00</span>
                        </div>
                    </div>
                    <div class="d-flex align-items-start justify-content-start popular-product">
                        <img src="https://rukminim1.flixcart.com/image/832/832/shirt/k/h/n/bfgreysht02-being-fab-40-original-imaecvnxyxg44vre.jpeg?q=70"
                            alt="" class="img-fluid pe-3 w-25">
                        <div>
                            <p class="mb-0">Shift Dress</p>
                            <span>$ 20.00</span>
                        </div>
                    </div>
                </div>

                <div class="col-md-6 col-lg-4 col-md-12 row g-3">
                    <h3 class="fs-5 popular-type">On Sale</h3>
                    <div class="d-flex align-items-start justify-content-start popular-product">
                        <img src="https://rukminim1.flixcart.com/image/832/832/shirt/k/h/n/bfgreysht02-being-fab-40-original-imaecvnxyxg44vre.jpeg?q=70"
                            alt="" class="img-fluid pe-3 w-25">
                        <div>
                            <p class="mb-0">T-shirt</p>
                            <span>$ 20.00</span>
                        </div>
                    </div>
                    <div class="d-flex align-items-start justify-content-start popular-product">
                        <img src="https://rukminim1.flixcart.com/image/832/832/shirt/k/h/n/bfgreysht02-being-fab-40-original-imaecvnxyxg44vre.jpeg?q=70"
                            alt="" class="img-fluid pe-3 w-25">
                        <div>
                            <p class="mb-0">Regular Jacket</p>
                            <span>$ 20.00</span>
                        </div>
                    </div>
                    <div class="d-flex align-items-start justify-content-start popular-product">
                        <img src="https://rukminim1.flixcart.com/image/832/832/shirt/k/h/n/bfgreysht02-being-fab-40-original-imaecvnxyxg44vre.jpeg?q=70"
                            alt="" class="img-fluid pe-3 w-25">
                        <div>
                            <p class="mb-0">Sari</p>
                            <span>$ 20.00</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- end of popular products-->    <!-- Footer Starts -->
    <footer class="Dressingnity_footer">
        <div class="widget_wrapper"
            style="background-image: url(http://demo.tortoizthemes.com/deneb-html/deneb-ltr/assets/images/footer_bg.png);">
            <div class="container">
                <div class="row">
                    <div class="col-lg-4 col-md-6 col-12">
                        <div class="widget widegt_about">
                            <div class="widget_title">
                                <img style="width: 300px;" src="Images/SVG Samples/Dressingnity (LOGO-final).svg"
                                    class="img-fluid" alt="">
                            </div>
                            <p>Quisque orci nisl, viverra et sem ac, tincidunt egestas massa. Morbi est arcu, hendrerit
                                ac vehicula condimentum, euismod nec tortor praesent consequat urna.</p>
                            <ul class="social">
                                <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                                <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                                <li><a href="#"><i class="fab fa-instagram"></i></a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 col-sm-12">
                        <div class="widget widget_link">
                            <div class="widget_title explore">
                                <h4>Explore</h4>
                            </div>
                            <ul class="footer-links">
                                <li><a href="About.php#AboutUs">About Us</a></li>
                                <li><a href="About.php">About Site</a></li>
                                <li><a href="Blog.php">Blog</a></li>
                                <li><a href="FAQ.php">FAQ</a></li>
                                <li><a href="Terms&Conditions.php">Terms & Conditions</a></li>
                                <li><a href="sitemap.xml">Sitemap</a></li>
                                <li><a href="index.php">Home</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 col-sm-12">
                        <div class="widget widget_contact">
                            <div class="widget_title">
                                <h4>Contact Us</h4>
                            </div>
                            <div class="contact_info">
                                <div class="single_info">
                                    <div class="icon" style="margin-right: 0px;">
                                        <i class="fas fa-phone-alt"></i>
                                    </div>
                                    <div class="single_info">
                                        <div class="icon">
                                            <i class="ri-phone-fill phone-icon"></i>
                                        </div>
                                        <div class="info">
                                            <p><a href="tel:+919246147999">+1800-121-3637</a></p>
                                        </div>
                                    </div>
                                    <div class="single_info">
                                        <div class="icon">
                                            <i class="ri-phone-fill phone-icon"></i>
                                        </div>
                                        <div class="info">
                                            <p><a href="tel:+919246147999">+91 924-614-7999</a></p>
                                        </div>
                                    </div>
                                    <!-- <div class="info">
                                        <p><a href="tel:+919246147999">1800-121-3637</a></p>
                                        <p><a href="tel:+919246147999">+91 924-614-7999</a></p>
                                    </div> -->
                                </div>
                                <div class="single_info">
                                    <div class="icon">
                                        <i class="fas fa-envelope"></i>
                                    </div>
                                    <div class="info">
                                        <p><a href="mailto:info@Dressingnity.com">info@Dressingnity.com</a></p>
                                    </div>
                                </div>
                                <div class="single_info">
                                    <div class="icon">
                                        <i class="fas fa-envelope"></i>
                                    </div>
                                    <div class="info">
                                        <p><a href="mailto:services@Dressingnity.com">services@Dressingnity.com</a></p>
                                    </div>
                                </div>
                                <div class="single_info">
                                    <div class="icon">
                                        <i class="fas fa-map-marker-alt"></i>
                                    </div>
                                    <div class="info">
                                        <p>Inmantec College,<span>Ghaziabad.</span></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="copyright_area">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="copyright_text">
                            <p>Copyright &copy; 2022 All rights reserved.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- Footer Ends -->

    <!-- Cookie Banner -->
    <div id="cb-cookie-banner" class="rounded-3 shadow-sm alert alert-dark text-center mb-0" role="alert">
        🍪 This website uses cookies to ensure you get the best experience on our website.
        <a href="https://www.cookiesandyou.com/" class="Cookies-link" target="blank">Learn more</a>
        <button type="button" class="cookie-btn btn btn-sm ms-3" onclick="window.cb_hideCookieBanner()">
            I Got It
        </button>
    </div>
    <!-- End of Cookie Banner -->

    <!-- Bootstrap JS Bundle -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-OERcA2EqjJCMA+/3y+gxIOqMEjwtxJY7qPCqsdltbNJuaOe923+mo//f6V8Qbsw3"
        crossorigin="anonymous"></script>
    <!-- Bootstrap JS Bundle -->

    <!-- Custom JS -->
    <script src="JavaScript/Cookies.js"></script>
    <!-- Custom JS -->
</body>

</html>